import os
import json
import time
import tiktoken
from openai import OpenAI
import PyPDF2


def load_config(config_file="config.json"):
    """Loads configuration from a JSON file."""
    try:
        with open(config_file, 'r') as f:
            config = json.load(f)
        return config
    except FileNotFoundError:
        raise FileNotFoundError(f"Config file '{config_file}' not found. Please create it (config.json) with API key and model.")
    except json.JSONDecodeError:
        raise json.JSONDecodeError(f"Error decoding JSON in '{config_file}'. Please check the file format.")

def extract_text_from_pdf(pdf_path):
    """Extracts text content from a PDF file."""
    text = ""
    try:
        with open(pdf_path, 'rb') as pdf_file:
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                text += page.extract_text()
        return text
    except Exception as e:
        print(f"Error reading PDF '{pdf_path}': {e}")
        return None

def query_model(model_str, prompt, system_prompt, open_router_api, tries=3, timeout=5.0):
    """Queries the specified language model using OpenRouter API."""
    for _ in range(tries):
        try:
            client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=open_router_api)
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ]
            completion = client.chat.completions.create(model=model_str, messages=messages)
            return completion.choices[0].message.content
        except Exception as e:
            print(f"Inference Exception (attempt {_ + 1}/{tries}): {e}")
            time.sleep(timeout)
    raise Exception(f"Max retries reached. Failed to query model after {tries} attempts.")

def check_pdf_discrepancies(folder_path, config):
    """
    Checks for discrepancies in PDF documents within a folder using an LLM.
    Lists out any problems found.
    """
    open_router_api_key = config.get("openrouter_api_key")
    model_name = config.get("model_name", "mistralai/mistral-medium") # Default model if not in config

    if not open_router_api_key:
        raise ValueError("OpenRouter API key not found in config.")

    pdf_files = [f for f in os.listdir(folder_path) if f.lower().endswith('.pdf')]

    if not pdf_files:
        print(f"No PDF files found in folder: {folder_path}")
        return

    print(f"Checking {len(pdf_files)} PDF files in folder: {folder_path}")

    for pdf_file in pdf_files:
        pdf_path = os.path.join(folder_path, pdf_file)
        print(f"\n--- Checking PDF: {pdf_file} ---")

        pdf_text = extract_text_from_pdf(pdf_path)
        if pdf_text:
            system_prompt = "You are a meticulous document reviewer. Your task is to identify any discrepancies in the document and also find out if there are any Logical errors like the numbers are correct. Provide a concise list of problems found. If no issues are found, state 'No discrepancies found.'"
            prompt = f"Please review the following text for discrepancies:\n\n{pdf_text}"

            try:
                llm_response = query_model(model_name, prompt, system_prompt, open_router_api_key)
                print("LLM Review Result:")
                print(llm_response)
            except Exception as e:
                print(f"Error during LLM query for {pdf_file}: {e}")
        else:
            print(f"Could not extract text from {pdf_file}. Skipping discrepancy check.")

if __name__ == "__main__":
    folder_to_check = "document"  # Replace with the folder containing your PDFs

    try:
        config = load_config()
        check_pdf_discrepancies(folder_to_check, config)
    except FileNotFoundError as e:
        print(e)
    except json.JSONDecodeError as e:
        print(e)
    except ValueError as e:
        print(e)
    except Exception as e:
        print(f"An unexpected error occurred: {e}")